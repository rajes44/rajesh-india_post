# India Post — Accessibility Baseline & Repository Architecture Audit

**Project type:** Preliminary accessibility audit + monorepo-style project foundation  
**Target:** https://www.indiapost.gov.in/  
**Prepared:** 15 November 2026

## Important audit status

This repository is a structured audit starter with desk-research findings and a repeatable manual test plan. It does **not** claim a completed Lighthouse run or verified keyboard test. No accessibility defect is marked as confirmed without browser evidence. Run the checklist in `docs/manual-test-checklist.md`, save screenshots/reports in `screenshots/`, and update `docs/audit-log.csv` with the actual observations before submitting this as a completed audit.

India Post publishes a Screen Reader Access page that states WCAG 2.0 Level AA compliance and compatibility with screen readers including JAWS. This is the site's published claim, not independent proof that every current page and workflow passes. See `docs/audit-report.md`.

## Repository layout

```text
client/       Small client-side project placeholder
server/       Small Node.js server placeholder
docs/         Audit report, architecture notes, test checklist and issue log
tests/        Automated smoke-test placeholder
screenshots/  Evidence captured during manual/Lighthouse testing
```

## Requirements

- Node.js 18+
- Chrome or Chromium
- Lighthouse (Chrome DevTools or `npx lighthouse`)

## Run the starter app

```bash
npm install
npm run dev
```

Open `http://localhost:3000`.

## Run a Lighthouse audit against India Post

Use Chrome DevTools on the live target page:

1. Open `https://www.indiapost.gov.in/`.
2. Open DevTools → Lighthouse.
3. Select **Accessibility** and **Desktop** (also repeat for Mobile if possible).
4. Generate the report and save it as HTML or JSON in `screenshots/`.
5. Record the exact page URL, date, device mode, score and failing audits in `docs/audit-log.csv`.

CLI alternative:

```bash
npx lighthouse https://www.indiapost.gov.in/ --only-categories=accessibility --output=html --output-path=./screenshots/india-post-lighthouse.html
```

## Keyboard-only test

Follow `docs/manual-test-checklist.md`. Use Tab, Shift+Tab, Enter, Space and arrow keys. Record the exact control and what happened; do not infer a failure from appearance alone.

## Before submission

- [ ] Complete Lighthouse run and save report.
- [ ] Complete keyboard-only checks and save evidence screenshots.
- [ ] Replace all `PENDING` values in `docs/audit-log.csv` with verified observations.
- [ ] Add five genuine issues only if five are actually found; otherwise report the actual count.
- [ ] Review `docs/audit-report.md` and update its status.
- [ ] Commit and push the repository to a public GitHub repository.
